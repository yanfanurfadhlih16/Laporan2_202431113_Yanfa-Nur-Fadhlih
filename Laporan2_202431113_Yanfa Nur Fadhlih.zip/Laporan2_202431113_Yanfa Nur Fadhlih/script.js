document.addEventListener('DOMContentLoaded', () => {

  // Hide / Show paragraf
  const titles = document.querySelectorAll('.issue-title');
  titles.forEach(title => {
    title.addEventListener('click', () => {
      const id = title.dataset.id;
      const desc = document.querySelector(`#issue-${id} .issue-desc`);

      if(desc.style.display === 'none'){
        if(confirm("Apakah Anda ingin menampilkan penjelasan ini?")){
          desc.style.display = '';
        }
      } else {
        if(confirm("Apakah Anda ingin menyembunyikan penjelasan ini?")){
          desc.style.display = 'none';
        }
      }
    });
  });

  // Mode tampilan
  const toggleBtn = document.getElementById('toggleModeBtn');
  toggleBtn.addEventListener('click', () => {
    const body = document.body;

    if(body.classList.contains("mode-rapi")){
      body.classList.remove("mode-rapi");
      body.classList.add("mode-berantakan");
      toggleBtn.textContent = "Mode: Berantakan";
    } else {
      body.classList.remove("mode-berantakan");
      body.classList.add("mode-rapi");
      toggleBtn.textContent = "Mode: Rapi";
    }
  });

});
